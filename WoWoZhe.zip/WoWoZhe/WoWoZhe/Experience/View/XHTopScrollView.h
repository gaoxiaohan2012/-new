//
//  XHTopScrollView.h
//  WoWoZhe
//
//  Created by MS on 15/11/3.
//  Copyright © 2015年 GHX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XHTopScrollView : UIScrollView



- (instancetype)initWithFrame:(CGRect)frame TitleArr:(NSArray *)titleArr ViewcontrollerArr:(NSArray *)vcArr;



@end
