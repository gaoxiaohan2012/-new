//
//  FirstModel.h
//  WoWoZhe
//
//  Created by MS on 15/10/23.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstModel : NSObject

@property (nonatomic,copy) NSString *add_time;
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *img;
@property (nonatomic,copy) NSString *item_url;
@property (nonatomic,copy) NSString *likes;
@property (nonatomic,copy) NSString *price;
@property (nonatomic,copy) NSString *source;
@property (nonatomic,copy) NSString *title;

@property (nonatomic,copy) NSString *preprice;
@property (nonatomic,copy) NSString *iid;


@end
