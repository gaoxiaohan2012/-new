//
//  menuModel.h
//  WoWoZhe
//
//  Created by MS on 15/10/23.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface menuModel : NSObject

@property (nonatomic,copy) NSString *icon;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *url;

@end
