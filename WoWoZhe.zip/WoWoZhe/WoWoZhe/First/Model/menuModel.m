//
//  menuModel.m
//  WoWoZhe
//
//  Created by MS on 15/10/23.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import "menuModel.h"

@implementation menuModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

- (id)valueForUndefinedKey:(NSString *)key {
    return nil;
}

@end
