//
//  CategaryButton.m
//  WoWoZhe
//
//  Created by xiaohan on 15/10/25.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import "CategaryButton.h"

@implementation CategaryButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
