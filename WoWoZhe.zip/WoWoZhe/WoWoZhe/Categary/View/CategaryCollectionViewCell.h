//
//  CategaryCollectionViewCell.h
//  WoWoZhe
//
//  Created by xiaohan on 15/10/25.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategaryCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
