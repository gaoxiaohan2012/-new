//
//  categaryModel.m
//  WoWoZhe
//
//  Created by xiaohan on 15/10/25.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import "categaryModel.h"

@implementation categaryModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
- (id)valueForUndefinedKey:(NSString *)key {
    return nil;
}

@end
