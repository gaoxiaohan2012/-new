//
//  CategaryViewController.h
//  WoWoZhe
//
//  Created by MS on 15/10/22.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import "BaseViewController.h"

@interface CategaryViewController : BaseViewController

@end
