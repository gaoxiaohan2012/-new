//
//  LoginViewController.h
//  WoWoZhe
//
//  Created by MS on 15/10/26.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
