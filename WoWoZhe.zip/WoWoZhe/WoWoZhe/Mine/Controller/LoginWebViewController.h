//
//  LoginWebViewController.h
//  WoWoZhe
//
//  Created by xiaohan on 15/10/27.
//  Copyright (c) 2015年 GHX. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface LoginWebViewController :UIViewController


@property (nonatomic,copy) NSString *urlStr;
@property (nonatomic,copy) NSString *client_id;
@property (nonatomic,copy) NSString *redirect_url;


@end
